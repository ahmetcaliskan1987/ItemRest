# ItemRest 0.3.0

* Replace the single optimal_strategy field with all screened candidate_solutions.
  Candidate reporting is the default; report = "optimal" is a deprecated alias.
* Reassess remaining items after removal, cache identical item sets, retain the
  no-removal baseline, and label bounded searches as incomplete.
* Add numerical admissibility, correlation positive-definiteness and explicit
  smoothing, convergence status, factor correlations, factor support, warnings,
  and branch-specific failure records. Unidentified subsets are skipped.
* Add explicit missing-data handling, effective pair counts, parameter checks,
  protected items, content notes, and scoring keys.
* Default ordering is discovery order; optional removal-count/variance ordering
  never selects a winner. Oblique explained variance uses mean model communality.
* Add factor-level alpha and model omega total, with separate raw, standardized,
  and selected-correlation alpha labels. Preserve signed loading ranges and add
  absolute ranges. Capture Howard failures below the secondary .30 threshold.
* Add holdout EFA, optional lavaan CFA, disjoint sample splitting, and bootstrap
  stability of the entire search with explicit failure/incompleteness denominators.
* Add DDMMYYYY date-based default seeds (e.g. label 05102026 / seed 5102026),
  caller RNG restoration, configurable parallel-analysis replications, and
  recorded settings and software provenance.
* Provide a reproducible simulated vignette and complete executable workflow.

# ItemRest 0.2.5.9000 (development version)

* Reassess low-loading and cross-loading items after each removal and test
  further combinations of the remaining flagged items. Each distinct item set
  is evaluated once and the factor count stays fixed throughout the search.
* Add iteration, step-specific and cumulative removal counts, remaining items,
  and remaining problem items to the removal summary while retaining existing
  columns.
* Require both low-loading and cross-loading problems to be resolved for optimal
  strategy selection and reporting.

# ItemRest 0.2.5

* Fixed: The factor loading range in the summary table now correctly displays raw values (including negative signs) instead of absolute values.
